# Security specification

## Implemented in milestone 0.2.0
- Argon2 password hashing via pwdlib.
- Access tokens signed with configurable secret and algorithm.
- Refresh tokens are opaque, stored only as SHA-256 digests, and rotated on refresh.
- Logout revokes a refresh session.
- Access token required for `/v1/auth/me`.
- Production startup rejects the development JWT secret.
- CORS origins are environment-configurable.

## Still required
Email verification, password reset, MFA, brute-force/rate limiting, login audit events, permission matrix, tenant isolation, CSRF strategy for browser token storage, secure cookie option, device management, session revocation UI, secrets manager, HTTPS, security headers, backup encryption and security testing. Current API returns refresh tokens in JSON; production web deployment should evaluate secure HttpOnly cookie transport and CSRF protections before release.
