# System architecture

Initial deployment is a modular monolith: one FastAPI API, PostgreSQL for durable state, Redis for cache/queues, and a separately runnable web frontend. AI inference is reserved for a separately deployable worker once a validated model and evaluation dataset are selected.

The frontend is web-first using Expo Router and React Native Web, preserving a path to Android/iOS without maintaining separate UI implementations.

Business domains are separated under `services/api/app/domains`. Quran canonical content is edition- and Riwayah-aware. No Quran text is seeded in this scaffold.
