# Changelog

## 0.2.0 — Identity foundation
- Added Argon2 password hashing.
- Added registration, login, refresh rotation, logout and current-user endpoints.
- Added user, role, user-role and refresh-session models.
- Added signed access tokens and hashed refresh-token persistence.
- Added environment-driven CORS and production JWT secret validation.

## 0.1.0 — Initial greenfield scaffold
- Created web-first Expo application shell.
- Created FastAPI modular monolith foundation.
- Added PostgreSQL and Redis Docker Compose services.
- Added initial SQLAlchemy models and Alembic environment.
- Added health/readiness/platform endpoints and initial pytest tests.
- Added project documentation baseline.
