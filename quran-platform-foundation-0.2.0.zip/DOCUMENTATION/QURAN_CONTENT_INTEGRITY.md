# Quran content integrity policy

- No Quranic text is generated or fabricated in the application.
- Canonical text must be sourced from a verified, attributable edition.
- Record source, version, Riwayah, license, import timestamp and checksum.
- Validate all 114 Surahs, ayah counts, ordering, duplicates and references before publication.
- Store canonical text separately from UI rendering, user notes and highlights.
- Do not silently normalize or mutate canonical text.
