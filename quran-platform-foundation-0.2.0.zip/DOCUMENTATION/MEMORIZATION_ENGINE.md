# Memorization engine

Not implemented in milestone 0.1.0. Design requirements: persist each learning/review event; distinguish exposure, guided practice, independent recall, passage continuity and delayed retention; calculate schedules server-side; version the scheduling algorithm; never award mastery from consumption alone.
