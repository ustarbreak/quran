# Technical debt and known gaps

1. No authentication, password hashing, MFA, sessions or RBAC yet.
2. ORM models are only an initial domain slice; tenant isolation and full constraints are pending.
3. Alembic environment exists but no initial revision has been generated.
4. Quran content is intentionally absent until a licensed, verified source and edition are selected.
5. Audio, reciter catalogue, offline caching and background playback are not implemented.
6. No validated Quran-aware speech model or benchmark exists in this scaffold.
7. Frontend currently contains a landing/workspace introduction, not completed portals.
8. CORS is development-only and must be environment-configured before deployment.
9. Secrets in `.env.example` are development placeholders; replace before any shared deployment.
10. CI, observability, backup restore drills, rate limiting and security scans remain pending.
