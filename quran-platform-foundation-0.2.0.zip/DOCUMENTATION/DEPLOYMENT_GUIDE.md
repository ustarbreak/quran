# Local deployment

1. Install Docker Engine/Desktop with Compose v2.
2. Copy `.env.example` to `.env`.
3. Run `docker compose up --build`.
4. Open web app at `http://localhost:8081` and API docs at `http://localhost:8000/docs`.
5. Stop with `docker compose down`; preserve data volumes unless intentionally resetting.

Before production: replace all development secrets, configure HTTPS and production CORS, add backups and restore verification, monitoring, migrations in deployment pipeline and security review.
