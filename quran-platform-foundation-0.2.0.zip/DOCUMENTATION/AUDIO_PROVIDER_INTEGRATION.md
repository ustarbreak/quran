# Audio provider integration

Not implemented in milestone 0.1.0. Future provider adapters must record reciter attribution, recording source, rights/redistribution terms, supported Riwayah and available timing granularity. Word-level timing must never be assumed when absent.
