# Development plan

## Next execution sequence
1. Make the API startup deterministic and add an initial Alembic migration.
2. Add backend configuration validation, structured errors and API versioning.
3. Implement identity: registration, verification workflow, password hashing, login, refresh rotation, logout and RBAC.
4. Build shared web design primitives and authenticated learner shell.
5. Select and document a verified Quran content provider/edition and licensing constraints.
6. Import and checksum canonical text; validate 114 surahs and ayah ordering.
7. Build Quran explorer and reader against persisted canonical content.
8. Add audio-provider abstraction and legally permitted reciter catalogue.
9. Implement Hifz learning events and backend-owned scheduling.
10. Continue with analytics, recitation evaluation, portals and deployment hardening.
