# Testing strategy

Initial pytest tests cover API health and truthful capability metadata. They are authored but have not yet been executed in this environment. Required next: unit/integration/authz/database tests, frontend typecheck/component tests, Playwright E2E, Docker build, migration tests, Quran integrity validation, load and security scans.
