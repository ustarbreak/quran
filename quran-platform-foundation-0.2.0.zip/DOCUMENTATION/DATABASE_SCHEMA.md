# Database schema — initial slice

Initial SQLAlchemy entities:
- `users`: identity placeholder (not yet exposed through public auth APIs)
- `quran_editions`: source, version, Riwayah and verification metadata
- `surah_references`: edition-scoped Surah numbering and ayah counts
- `learning_events`: append-oriented learner event records

UUID-shaped string identifiers are used in the initial models. The schema is not yet a complete production schema; additional domains, foreign keys, tenant constraints, indexes and migrations are required.
