# UI/UX specification

Initial visual foundation: deep forest/navy green, warm ivory, muted gold and restrained emerald. The landing shell is responsive and designed for web first. Specialized Mushaf reader, Hifz workspace and role-based portal layouts are future milestones. Arabic RTL, French and English localization are not yet implemented.
