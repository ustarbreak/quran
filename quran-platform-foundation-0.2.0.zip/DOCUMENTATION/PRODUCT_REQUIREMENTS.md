# Product requirements

The product follows the uploaded master specification: Quran exploration and reading, authentic audio, guided Hifz, independent recall, long-term retention, carefully validated recitation assessment, learning comprehension, learner analytics, parent/teacher/academy/admin portals, privacy and cross-device continuity.

The initial milestone only lays down the foundation. No unimplemented capability should be presented as available.
