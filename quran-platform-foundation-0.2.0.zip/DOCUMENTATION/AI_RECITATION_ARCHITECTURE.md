# AI recitation architecture

Not implemented in milestone 0.1.0. No ordinary Arabic ASR output will be represented as validated Quran recitation or Tajweed assessment. A future pipeline requires Quran-aware alignment, held-out evaluation, confidence calibration, model versioning and qualified human review.
