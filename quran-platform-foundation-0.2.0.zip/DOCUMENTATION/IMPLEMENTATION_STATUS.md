# Implementation status

## Milestone 0.2.0 — Identity foundation
- [x] Registration API with email normalization and learner role assignment
- [x] Argon2 password hashing through pwdlib
- [x] Login API and short-lived signed access tokens
- [x] Opaque refresh tokens stored as SHA-256 digests
- [x] Refresh token rotation and logout revocation
- [x] Authenticated `/v1/auth/me` endpoint
- [x] Initial RBAC data model (learner role assigned; permission matrix pending)
- [x] Environment-driven CORS and production secret guard
- [ ] Email verification delivery and recovery workflow
- [ ] MFA and device/session management UI
- [ ] Role/permission enforcement for staff and tenant roles
- [ ] Initial migration generation and execution
- [ ] Runtime/API tests and frontend integration

**Verified completion:** 0% of production acceptance criteria. Source implementation exists; runtime and database verification have not yet been executed.
