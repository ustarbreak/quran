# API specification — current endpoints

System:
- `GET /health`
- `GET /ready`
- `GET /v1/platform`

Identity:
- `POST /v1/auth/register` — email, display_name, password (12+ chars), preferred_language (`en|fr|ar`)
- `POST /v1/auth/login` — email/password; returns access and refresh token plus user
- `POST /v1/auth/refresh` — rotates refresh token
- `POST /v1/auth/logout` — revokes supplied refresh token
- `GET /v1/auth/me` — requires `Authorization: Bearer <access_token>`

OpenAPI docs: `/docs` in development.
