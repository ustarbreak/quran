from app.domains.identity.schemas import RegisterRequest, LoginRequest

def test_registration_rejects_short_password():
    try:
        RegisterRequest(email="reader@example.com", display_name="Reader", password="short")
    except Exception:
        return
    raise AssertionError("A short password must be rejected")

def test_registration_accepts_supported_language():
    payload = RegisterRequest(email="reader@example.com", display_name="Reader", password="long-enough-password", preferred_language="ar")
    assert payload.preferred_language == "ar"
