from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_platform_does_not_claim_fake_ai():
    response = client.get("/v1/platform")
    assert response.status_code == 200
    assert response.json()["ai_recitation_assessment"] == "not_configured"
