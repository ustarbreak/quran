from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, model_validator

class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = "postgresql+psycopg://quran:quran_dev_password@localhost:5432/quran_platform"
    redis_url: str = "redis://localhost:6379/0"
    jwt_secret: str = "DEV_ONLY_CHANGE_THIS_SECRET_TO_A_RANDOM_64_CHAR_VALUE"
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = 15
    refresh_token_days: int = 30
    cors_origins: str = "http://localhost:8081,http://127.0.0.1:8081"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @model_validator(mode="after")
    def validate_production_secrets(self):
        if self.app_env == "production" and self.jwt_secret.startswith("DEV_ONLY"):
            raise ValueError("JWT_SECRET must be replaced in production")
        return self

    @property
    def allowed_origins(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]

settings = Settings()
