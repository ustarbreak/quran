from fastapi import APIRouter
from sqlalchemy import text
from app.db.session import engine

router = APIRouter()

@router.get("/health", tags=["system"])
def health():
    return {"status": "ok", "service": "quran-platform-api"}

@router.get("/ready", tags=["system"])
def readiness():
    with engine.connect() as connection:
        connection.execute(text("SELECT 1"))
    return {"status": "ready", "database": "reachable"}

@router.get("/v1/platform", tags=["platform"])
def platform_info():
    return {
        "name": "Quran Learning Platform",
        "stage": "identity-foundation",
        "quran_content_loaded": False,
        "ai_recitation_assessment": "not_configured"
    }
