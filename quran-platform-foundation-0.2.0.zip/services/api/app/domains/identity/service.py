from datetime import datetime, timezone
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.config import settings
from app.core.security import hash_password, verify_password, new_refresh_token, digest_token, refresh_expiry
from app.core.tokens import create_access_token
from app.domains.identity.models import User, Role, UserRole, RefreshSession

class IdentityError(Exception):
    pass

def register_user(db: Session, *, email: str, display_name: str, password: str, preferred_language: str) -> User:
    normalized_email = email.strip().lower()
    existing = db.scalar(select(User).where(User.email == normalized_email))
    if existing:
        raise IdentityError("An account with this email already exists")
    user = User(email=normalized_email, display_name=display_name.strip(), password_hash=hash_password(password), preferred_language=preferred_language)
    db.add(user)
    db.flush()
    learner_role = db.scalar(select(Role).where(Role.name == "learner"))
    if learner_role is None:
        learner_role = Role(name="learner")
        db.add(learner_role)
        db.flush()
    db.add(UserRole(user_id=user.id, role_id=learner_role.id))
    db.commit()
    db.refresh(user)
    return user

def authenticate(db: Session, *, email: str, password: str) -> tuple[User, str, str]:
    user = db.scalar(select(User).where(User.email == email.strip().lower()))
    if user is None or not verify_password(password, user.password_hash) or not user.is_active:
        raise IdentityError("Invalid email or password")
    raw_refresh = new_refresh_token()
    session = RefreshSession(user_id=user.id, token_digest=digest_token(raw_refresh), expires_at=refresh_expiry(settings.refresh_token_days))
    db.add(session)
    db.commit()
    return user, create_access_token(user.id), raw_refresh

def rotate_refresh_token(db: Session, raw_token: str) -> tuple[User, str, str]:
    session = db.scalar(select(RefreshSession).where(RefreshSession.token_digest == digest_token(raw_token)).with_for_update())
    now = datetime.now(timezone.utc)
    if session is None or session.revoked_at is not None or session.expires_at <= now:
        raise IdentityError("Invalid or expired refresh token")
    user = db.get(User, session.user_id)
    if user is None or not user.is_active:
        raise IdentityError("User is unavailable")
    session.revoked_at = now
    new_raw = new_refresh_token()
    db.add(RefreshSession(user_id=user.id, token_digest=digest_token(new_raw), expires_at=refresh_expiry(settings.refresh_token_days)))
    db.commit()
    return user, create_access_token(user.id), new_raw

def revoke_refresh_token(db: Session, raw_token: str) -> None:
    session = db.scalar(select(RefreshSession).where(RefreshSession.token_digest == digest_token(raw_token)).with_for_update())
    if session is not None and session.revoked_at is None:
        session.revoked_at = datetime.now(timezone.utc)
        db.commit()
