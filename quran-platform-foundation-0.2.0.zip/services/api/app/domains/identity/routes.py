from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user
from app.core.config import settings
from app.domains.identity.models import User
from app.domains.identity.schemas import RegisterRequest, LoginRequest, UserResponse, TokenResponse
from app.domains.identity.service import register_user, authenticate, rotate_refresh_token, revoke_refresh_token, IdentityError

router = APIRouter(prefix="/v1/auth", tags=["identity"])

@router.post("/register", response_model=UserResponse, status_code=201)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    try:
        return register_user(db, email=str(payload.email), display_name=payload.display_name, password=payload.password, preferred_language=payload.preferred_language)
    except IdentityError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    try:
        user, access, refresh = authenticate(db, email=str(payload.email), password=payload.password)
        return TokenResponse(access_token=access, expires_in=settings.access_token_minutes * 60, refresh_token=refresh, user=user)
    except IdentityError:
        raise HTTPException(status_code=401, detail="Invalid email or password")

@router.post("/refresh", response_model=TokenResponse)
def refresh(payload: dict, db: Session = Depends(get_db)):
    raw = payload.get("refresh_token")
    if not isinstance(raw, str) or not raw:
        raise HTTPException(status_code=422, detail="refresh_token is required")
    try:
        user, access, new_refresh = rotate_refresh_token(db, raw)
        return TokenResponse(access_token=access, expires_in=settings.access_token_minutes * 60, refresh_token=new_refresh, user=user)
    except IdentityError:
        raise HTTPException(status_code=401, detail="Invalid or expired refresh token")

@router.post("/logout", status_code=204)
def logout(payload: dict, db: Session = Depends(get_db)):
    raw = payload.get("refresh_token")
    if isinstance(raw, str) and raw:
        revoke_refresh_token(db, raw)
    return None

@router.get("/me", response_model=UserResponse)
def me(user: User = Depends(get_current_user)):
    return user
