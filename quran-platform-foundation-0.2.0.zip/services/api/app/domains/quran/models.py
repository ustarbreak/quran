from uuid import uuid4
from sqlalchemy import String, Integer, Boolean, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.db.session import Base

class QuranEdition(Base):
    __tablename__ = "quran_editions"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    riwayah: Mapped[str] = mapped_column(String(80), nullable=False)
    source_name: Mapped[str] = mapped_column(String(160), nullable=False)
    source_version: Mapped[str] = mapped_column(String(80), nullable=False)
    checksum: Mapped[str | None] = mapped_column(String(128), nullable=True)
    verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

class SurahReference(Base):
    __tablename__ = "surah_references"
    __table_args__ = (UniqueConstraint("edition_id", "surah_number"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    edition_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    surah_number: Mapped[int] = mapped_column(Integer, nullable=False)
    ayah_count: Mapped[int] = mapped_column(Integer, nullable=False)
    canonical_name: Mapped[str] = mapped_column(String(120), nullable=False)
