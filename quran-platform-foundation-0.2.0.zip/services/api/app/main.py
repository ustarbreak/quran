from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import router
from app.domains.identity.routes import router as identity_router
from app.core.config import settings

app = FastAPI(
    title="Quran Learning Platform API",
    version="0.2.0",
    description="Web-first Quran learning and memorization platform API."
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
)
app.include_router(router)
app.include_router(identity_router)
