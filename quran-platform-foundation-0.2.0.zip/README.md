# Quran Learning Platform

Greenfield, web-first foundation for a Quran learning and Hifz ecosystem.

## Stack
- Web-first frontend: Expo + React Native + TypeScript + Expo Router (web target)
- Backend: FastAPI, SQLAlchemy 2, Pydantic, Alembic
- Data: PostgreSQL, Redis
- Local infrastructure: Docker Compose

## Quick start
1. Copy `.env.example` to `.env`.
2. Run `docker compose up --build`.
3. Frontend: http://localhost:8081
4. API docs: http://localhost:8000/docs
5. Health: http://localhost:8000/health

The first milestone establishes the runnable foundation, health endpoint, database connectivity, initial domain models, and a web-first shell. It does **not** claim that Quran text, audio, AI recitation assessment, authentication, or Hifz workflows are production-complete.

## Project layout
- `apps/web`: Expo web application
- `services/api`: FastAPI modular monolith
- `infra`: local infrastructure configuration
- `DOCUMENTATION`: audit/status/architecture/security/roadmap records

## Quran content integrity
No Quran text is fabricated or bundled in this starter. Integrate a verified source only after recording edition, Riwayah, licensing, provenance and checksum metadata. Canonical text must be immutable.
