import { ScrollView, StyleSheet, Text, View, Pressable } from 'react-native';

const modules = [
  { title: 'Quran reader', description: 'Explore the Mushaf and continue your reading.', icon: '۞', state: 'Content source pending' },
  { title: 'Hifz workspace', description: 'Build a structured memorization and revision routine.', icon: '✦', state: 'Coming in Phase 4' },
  { title: 'Recitation studio', description: 'Record practice and review verified feedback.', icon: '◉', state: 'AI validation pending' },
];

export default function HomeScreen() {
  return <ScrollView style={styles.page} contentContainerStyle={styles.container}>
    <View style={styles.nav}>
      <View style={styles.brandMark}><Text style={styles.brandIcon}>۞</Text></View>
      <View style={{ flex: 1 }}>
        <Text style={styles.brand}>NOOR</Text>
        <Text style={styles.brandSub}>QURAN LEARNING</Text>
      </View>
      <Text style={styles.lang}>EN</Text>
    </View>

    <View style={styles.hero}>
      <Text style={styles.eyebrow}>A MORE MINDFUL WAY TO LEARN</Text>
      <Text style={styles.heroTitle}>Read with purpose.{"\n"}Memorize with clarity.</Text>
      <Text style={styles.heroText}>A thoughtful space for Quran reading, guided memorization and lasting revision.</Text>
      <Pressable style={styles.primary} accessibilityRole="button">
        <Text style={styles.primaryText}>Explore your learning space  →</Text>
      </Pressable>
      <Text style={styles.disclaimer}>Your learning journey starts here. Sign-in and learner data will be enabled in the identity phase.</Text>
    </View>

    <View style={styles.sectionHeader}>
      <Text style={styles.sectionEyebrow}>YOUR LEARNING SPACE</Text>
      <Text style={styles.sectionTitle}>Designed around the journey</Text>
    </View>
    <View style={styles.cards}>
      {modules.map((item) => <View key={item.title} style={styles.card}>
        <View style={styles.cardIcon}><Text style={styles.cardIconText}>{item.icon}</Text></View>
        <Text style={styles.cardTitle}>{item.title}</Text>
        <Text style={styles.cardDescription}>{item.description}</Text>
        <Text style={styles.cardState}>{item.state}</Text>
      </View>)}
    </View>
    <View style={styles.footer}>
      <Text style={styles.footerTitle}>Built on trust and authenticity.</Text>
      <Text style={styles.footerText}>Canonical Quran text will only be integrated from verified, attributed sources. No generated Quran text or simulated recitation scores.</Text>
      <Text style={styles.copyright}>NOOR · QURAN LEARNING PLATFORM · FOUNDATION 0.1.0</Text>
    </View>
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#F7F5EF' },
  container: { maxWidth: 1120, width: '100%', alignSelf: 'center', paddingHorizontal: 28, paddingBottom: 64 },
  nav: { height: 88, flexDirection: 'row', alignItems: 'center', gap: 13, borderBottomWidth: 1, borderBottomColor: '#E8E3D8' },
  brandMark: { width: 42, height: 42, borderRadius: 14, backgroundColor: '#142B2A', alignItems: 'center', justifyContent: 'center' },
  brandIcon: { color: '#D8B66A', fontSize: 25 },
  brand: { color: '#172D2B', fontSize: 15, letterSpacing: 3, fontWeight: '800' },
  brandSub: { color: '#8A806E', fontSize: 8, letterSpacing: 2, marginTop: 3 },
  lang: { color: '#6F756B', fontSize: 12, letterSpacing: 1 },
  hero: { paddingTop: 86, paddingBottom: 82, maxWidth: 720 },
  eyebrow: { color: '#9A7B42', fontSize: 11, letterSpacing: 2.4, fontWeight: '700', marginBottom: 20 },
  heroTitle: { color: '#172D2B', fontSize: 52, lineHeight: 61, fontWeight: '600', letterSpacing: -1.8 },
  heroText: { color: '#69716A', fontSize: 17, lineHeight: 28, marginTop: 22, maxWidth: 570 },
  primary: { backgroundColor: '#183632', paddingVertical: 16, paddingHorizontal: 22, borderRadius: 8, alignSelf: 'flex-start', marginTop: 30 },
  primaryText: { color: '#F9F6EE', fontWeight: '600', fontSize: 13 },
  disclaimer: { color: '#8A8D83', fontSize: 11, lineHeight: 18, marginTop: 15, maxWidth: 500 },
  sectionHeader: { borderTopWidth: 1, borderTopColor: '#E5E0D5', paddingTop: 36, marginBottom: 22 },
  sectionEyebrow: { color: '#9A7B42', fontSize: 10, letterSpacing: 2, fontWeight: '700' },
  sectionTitle: { color: '#172D2B', fontSize: 27, fontWeight: '600', marginTop: 9 },
  cards: { flexDirection: 'row', flexWrap: 'wrap', gap: 16 },
  card: { flexGrow: 1, flexBasis: 260, backgroundColor: '#FFFEFA', borderColor: '#E9E4D9', borderWidth: 1, borderRadius: 12, padding: 22, minHeight: 205 },
  cardIcon: { width: 38, height: 38, backgroundColor: '#F1EBDD', borderRadius: 11, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  cardIconText: { color: '#92733C', fontSize: 20 },
  cardTitle: { color: '#1C302D', fontSize: 17, fontWeight: '700' },
  cardDescription: { color: '#73786F', fontSize: 13, lineHeight: 20, marginTop: 8 },
  cardState: { color: '#9A7B42', fontSize: 10, letterSpacing: 0.5, marginTop: 16 },
  footer: { marginTop: 64, backgroundColor: '#183632', borderRadius: 14, padding: 28 },
  footerTitle: { color: '#F5F1E7', fontSize: 20, fontWeight: '600' },
  footerText: { color: '#C6CEC3', fontSize: 13, lineHeight: 21, marginTop: 10, maxWidth: 680 },
  copyright: { color: '#A9B5A8', fontSize: 9, letterSpacing: 1.4, marginTop: 30 }
});
